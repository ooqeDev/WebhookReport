package com.ooqe.WebhookReport;

public class ReportTarget {

    public static String targetName;

}
