package com.ooqe.WebhookReport;

public class Fifth {

    public static String FifthBox;

}
