package com.ooqe.WebhookReport;

public class Third {

    public static String ThirdBox;

}
