package com.ooqe.WebhookReport;

public class First {

    public static String FirstBox;

}
