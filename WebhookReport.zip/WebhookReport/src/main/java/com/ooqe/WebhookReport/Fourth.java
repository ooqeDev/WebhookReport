package com.ooqe.WebhookReport;

public class Fourth {

    public static String FourthBox;

}
