package com.ooqe.WebhookReport;

public class Second {

    public static String SecondBox;

}
