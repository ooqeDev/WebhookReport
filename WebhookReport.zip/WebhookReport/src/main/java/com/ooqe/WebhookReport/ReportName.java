package com.ooqe.WebhookReport;

public class ReportName {

    public static String playerName;

}
